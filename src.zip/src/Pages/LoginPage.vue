<script setup>
import Login from '../components/Login.vue';
</script>

<template>
  <Login/>
</template>