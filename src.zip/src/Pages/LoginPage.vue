<script setup>
import Login from '../components/auth/LoginForm.vue';
</script>

<template>
  <Login/>
</template>