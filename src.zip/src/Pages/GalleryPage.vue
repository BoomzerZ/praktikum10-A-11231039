<template>
  <section class="p-6 max-w-6xl mx-auto">
    <h2 class="text-3xl font-bold mb-4">Unlockable</h2>
    <div class="mb-6 text-sm text-slate-500">Progress: {{ unlockedCount }} / {{ monsters.length }} unlocked</div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
      <MonsterCard
        v-for="m in pageItems"
        :key="m.id"
        :monster="m"
        @open="openMonster"
      />
    </div>

    <div class="mt-8 flex items-center justify-center">
      <Pagination :current="currentPage" :total="totalPages" :maxVisible="5" @change="goPage" />
    </div>

    <MonsterModal v-if="open" :monster="selected" @close="open = false" />
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import MonsterCard from '../components/gallery/MonsterCard.vue'
import MonsterModal from '../components/gallery/MonsterModal.vue'
import Pagination from '../components/Pagination.vue'
import { getUnlocked } from '../utils/galleryHelper.js'

// static monster list (example) - you can move this to separate JSON
const monsters = [
  // provide ids 1..N, images optional
  { id: 1, name: 'Slime', hearts: 3, bio: 'A cute slime', image: '/assets/monsters/slime.png', isBoss: false },
  { id: 2, name: 'Goblin', hearts: 3, bio: 'Sneaky goblin', image: '/assets/monsters/goblin.png', isBoss: false },
  { id: 3, name: 'Orc', hearts: 4, bio: 'Strong orc', image: '/assets/monsters/orc.png', isBoss: false },
  // ... up to whatever
  { id: 10, name: 'Dragon', hearts: 6, bio: 'Ancient dragon', image: '/assets/monsters/dragon.png', isBoss: true }
  // add more to reach many pages...
]

const perPage = 15
const currentPage = ref(1)
const open = ref(false)
const selected = ref(null)

const totalPages = computed(() => Math.max(1, Math.ceil(monsters.length / perPage)))
const unlockedIds = computed(() => getUnlocked())
const unlockedCount = computed(() => unlockedIds.value.length)

const pageItems = computed(() => {
  const start = (currentPage.value - 1) * perPage
  return monsters.slice(start, start + perPage)
})

function goPage(n) {
  currentPage.value = n
}

function openMonster(monster) {
  selected.value = monster
  open.value = true
}
</script>

<style scoped>
/* small layout tweaks if needed */
</style>
