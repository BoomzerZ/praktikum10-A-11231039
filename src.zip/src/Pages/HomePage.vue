<script setup>
import Navbar from '../components/layout/Navbar.vue'
import Hero from '../components/home/Hero.vue'
import Overview from '../components/home/Overview.vue'
import CTA from '../components/home/CTA.vue'
import Footer from '../components/layout/Footer.vue'
</script>

<template>
  <Navbar/>
  <Hero/>
  <Overview/>
  <CTA/>
  <Footer/>
</template>
