<script setup>
import SignUp from '../components/auth/SignUpForm.vue';
</script>

<template>
  <SignUp/>
</template>