<script setup>
import SignUp from '@/components/SignUp.vue';
</script>

<template>
  <SignUp/>
</template>