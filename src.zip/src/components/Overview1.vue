<template>
  <section class="bg-[#f4f2ff] py-16">
    <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 space-y-16">

      <!-- Cara Bermain -->
      <div class="text-center space-y-8">
        <h2 class="text-2xl md:text-3xl font-semibold text-gray-900">Cara Bermain</h2>
        <div class="grid gap-6 md:grid-cols-3">
          <div class="bg-white rounded-2xl shadow-md px-6 py-8 flex flex-col items-center">
            <img src="/src/assets/LogoQuiz.png" alt="Jawab Kuis" class="h-12 w-12 mb-4">
            <h3 class="font-semibold text-gray-900 mb-2">Jawab Kuis</h3>
            <p class="text-sm text-gray-600">
              Pilih kategori soal, baca pertanyaan, lalu jawab pilihan ganda untuk menyerang musuh.
            </p>
          </div>
          <div class="bg-white rounded-2xl shadow-md px-6 py-8 flex flex-col items-center">
            <img src="/src/assets/LogoMonster.png" alt="Kalahkan Musuh" class="h-12 w-12 mb-4">
            <h3 class="font-semibold text-gray-900 mb-2">Kalahkan Musuh</h3>
            <p class="text-sm text-gray-600">
              Jawaban yang benar akan mengurangi HP musuh. Kumpulkan kombo jawaban untuk bonus damage.
            </p>
          </div>
          <div class="bg-white rounded-2xl shadow-md px-6 py-8 flex flex-col items-center">
            <img src="/src/assets/LogoLevel.png" alt="Menangkan Level" class="h-12 w-12 mb-4">
            <h3 class="font-semibold text-gray-900 mb-2">Menangkan Level</h3>
            <p class="text-sm text-gray-600">
              Kalahkan semua musuh di satu stage untuk naik level dan membuka musuh serta arena baru.
            </p>
          </div>
        </div>
      </div>

      <!-- Kategori Kuis -->
      <div class="text-center space-y-6">
        <h2 class="text-2xl md:text-3xl font-semibold text-gray-900">Kategori Kuis</h2>
        <p class="text-sm text-gray-600 max-w-2xl mx-auto">
          Pilih kategori favoritmu untuk menantang musuh dengan jenis pertanyaan yang berbeda.
        </p>
        <div class="flex flex-wrap justify-center gap-4 mt-4">
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoUmum.png" alt="Umum" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Umum</span>
          </div>
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoSejarah.png" alt="Sejarah" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Sejarah</span>
          </div>
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoSains.png" alt="Sains" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Sains</span>
          </div>
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoGeografi.png" alt="Geografi" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Geografi</span>
          </div>
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoMatematika.png" alt="Matematika" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Matematika</span>
          </div>
          <div class="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
            <img src="/src/assets/LogoSastra.png" alt="Sastra" class="h-7 w-7">
            <span class="text-sm font-medium text-gray-800">Sastra</span>
          </div>
        </div>
      </div>

      <!-- Musuh yang Dihadapi -->
      <div class="text-center space-y-8">
        <h2 class="text-2xl md:text-3xl font-semibold text-gray-900">Musuh yang Dihadapi</h2>
        <p class="text-sm text-gray-600 max-w-2xl mx-auto">
          Setiap musuh punya HP, Attack, dan Defense yang berbeda. Semakin tinggi levelmu, semakin kuat musuh yang muncul.
        </p>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          <div class="bg-white rounded-2xl shadow px-4 py-5 flex flex-col items-center">
            <img src="/src/assets/pocong.png" alt="Goblin" class="h-12 w-12 mb-3">
            <h3 class="font-semibold text-gray-900 mb-1">Goblin</h3>
            <ul class="text-xs text-gray-600 space-y-1">
              <li>❤️ Health: 100</li>
              <li>⚔️ Attack: 5</li>
              <li>🛡 Defense: 0</li>
            </ul>
          </div>
          <div class="bg-white rounded-2xl shadow px-4 py-5 flex flex-col items-center">
            <img src="/src/assets/pocong.png" alt="Orc" class="h-12 w-12 mb-3">
            <h3 class="font-semibold text-gray-900 mb-1">Orc</h3>
            <ul class="text-xs text-gray-600 space-y-1">
              <li>❤️ Health: 150</li>
              <li>⚔️ Attack: 10</li>
              <li>🛡 Defense: 5</li>
            </ul>
          </div>
          <div class="bg-white rounded-2xl shadow px-4 py-5 flex flex-col items-center">
            <img src="/src/assets/pocong.png" alt="Ekdina" class="h-12 w-12 mb-3">
            <h3 class="font-semibold text-gray-900 mb-1">Ekdina</h3>
            <ul class="text-xs text-gray-600 space-y-1">
              <li>❤️ Health: 200</li>
              <li>⚔️ Attack: 15</li>
              <li>🛡 Defense: 10</li>
            </ul>
          </div>
          <div class="bg-white rounded-2xl shadow px-4 py-5 flex flex-col items-center">
            <img src="/src/assets/pocong.png" alt="Naga" class="h-12 w-12 mb-3">
            <h3 class="font-semibold text-gray-900 mb-1">Naga</h3>
            <ul class="text-xs text-gray-600 space-y-1">
              <li>❤️ Health: 250</li>
              <li>⚔️ Attack: 25</li>
              <li>🛡 Defense: 20</li>
            </ul>
          </div>
          <div class="bg-white rounded-2xl shadow px-4 py-5 flex flex-col items-center">
            <img src="/src/assets/pocong.png" alt="Demonlord" class="h-12 w-12 mb-3">
            <h3 class="font-semibold text-gray-900 mb-1">Demonlord</h3>
            <ul class="text-xs text-gray-600 space-y-1">
              <li>❤️ Health: 300</li>
              <li>⚔️ Attack: 30</li>
              <li>🛡 Defense: 25</li>
            </ul>
          </div>
        </div>
      </div>

    </div>
  </section>
</template>
