<template>
  <div class="flex items-center gap-3 justify-center mt-8">
    <button @click="go(prev)" :disabled="current === 1" class="p-3 rounded-full border">‹</button>

    <button
      v-for="p in pagesToShow"
      :key="p"
      @click="go(p)"
      :class="['w-10 h-10 rounded-full', p === current ? 'bg-indigo-600 text-white' : 'bg-white']"
    >
      {{ p }}
    </button>

    <span v-if="showEllipsis" class="px-2">…</span>

    <button v-if="endPage > lastShown" @click="go(lastShown + 1)" class="px-3">›</button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({
  current: { type: Number, default: 1 },
  total: { type: Number, required: true },
  maxVisible: { type: Number, default: 5 }
})
const emit = defineEmits(['change'])

const lastShown = computed(() => Math.min(props.total, props.maxVisible))
const endPage = props.total

const pagesToShow = computed(() => {
  // simple: show 1..min(total,maxVisible)
  return Array.from({ length: Math.min(props.total, props.maxVisible) }, (_, i) => i + 1)
})
const showEllipsis = computed(() => props.total > props.maxVisible)

function go(p) {
  if (p < 1 || p > props.total) return
  emit('change', p)
}
</script>
