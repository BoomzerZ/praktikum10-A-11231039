<template>
  <div class="bg-white rounded-xl shadow p-6 text-center cursor-pointer" @click="open">
    <div class="h-24 w-24 rounded-full mx-auto mb-4 bg-gray-100 flex items-center justify-center">
      <img v-if="monster.sprite" :src="monster.sprite" class="h-full w-full object-contain" />
      <div v-else class="text-sm text-gray-400">sprite</div>
    </div>
    <h4 class="font-semibold">{{ monster.name }}</h4>
    <div class="text-xs text-gray-600 mt-2">
      <div>❤️ Health: {{ monster.health }}</div>
      <div>⚔️ Attack: {{ monster.attack }}</div>
      <div>🛡 Defense: {{ monster.defense }}</div>
    </div>
    <div v-if="!monster.unlocked" class="absolute inset-0 bg-white/70 rounded-xl flex items-center justify-center text-gray-500">Locked</div>
  </div>
</template>

<script setup>
const props = defineProps({ monster: Object })
const emit = defineEmits(['open'])

function open() {
  if (!props.monster.unlocked) return
  emit('open', props.monster)
}
</script>

<style scoped>
/* optionally position locked overlay */
</style>
