<template>
  <div class="fixed inset-0 bg-black/40 flex items-center justify-center" @click.self="$emit('close')">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
      <h2 class="text-xl font-bold">{{ monster.name }}</h2>
      <p class="text-sm text-slate-600 mt-2">
        {{ monster.lore }}
      </p>
      <p class="mt-4 text-sm">Dibunuh: {{ monster.killCount }}x</p>

      <button
        class="mt-6 px-4 py-2 bg-indigo-600 text-white rounded-lg"
        @click="$emit('close')"
      >
        Tutup
      </button>
    </div>
  </div>
</template>

<script setup>
defineProps({ monster: Object })
</script>
