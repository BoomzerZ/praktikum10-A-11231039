<template>
  <section
    class="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500 text-white py-24"
  >
    <div class="max-w-4xl mx-auto px-6 text-center">
      <h2 class="text-3xl md:text-4xl font-bold mb-4">
        Seberapa Jauh Petualanganmu?
      </h2>

      <p class="text-white/90 mb-8">
        Kalahkan monster, naikkan level, dan buktikan kamu layak masuk leaderboard.
      </p>

      <!-- Progress -->
      <div class="flex justify-center gap-8">
        <div>
          <p class="text-4xl font-extrabold">31%</p>
          <p class="text-sm opacity-80">Monster Unlocked</p>
        </div>
        <div>
          <p class="text-4xl font-extrabold">5</p>
          <p class="text-sm opacity-80">Monster Dikalahkan</p>
        </div>
      </div>
    </div>
  </section>
</template>
