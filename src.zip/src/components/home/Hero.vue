<template>
  <header class="pt-16">
    <div class="bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-400 text-white">
      <div class="container mx-auto px-6 py-20 text-center">
        <h1 class="text-4xl md:text-6xl font-extrabold">EdVenture Arena</h1>
        <p class="mt-4 text-lg text-white/90">Platform edukasi interaktif yang mengubah belajar menjadi petualangan</p>
        <div class="mt-8 flex justify-center gap-4">
          <router-link to="/game" class="bg-white text-gray-900 px-6 py-3 rounded-lg shadow hover:shadow-lg">Mulai Bermain</router-link>
          <router-link to="/about" class="bg-white/20 border border-white/30 px-6 py-3 rounded-lg hover:bg-white/30">Pelajari Lanjut</router-link>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
// stateless presentational
</script>
