<template>
  <header class="pt-16">
    <div class="grid gap-6 md:flex-cols-2">
        <div class="bg-white-400 text-black md:justify-between" py-10>
            <a href="#" class="md:flex md:justify-right">
                <img src="/src/assets/LogoPolos.png" class="h-40 me-3 -mt-10 shadow" alt="EdVenture Logo" />
            </a>

            <div class="container mx-auto px-3 py-10 text-flex">
                <h1 class="text-2xl md:text-3xl font-extrabold">Michael Peter Valentino Situmeang</h1>
                <h2 class="text-1xl md:text-1xl font-semibold mt-4">11231039-Informatika-ITK</h2>
                <p class="mt-4 text-lg text-black/90">
                Saya adalah Mahaiswa Lorem ipsum dolor sit amet consectur adispicing elite. Phaselius aliguam nisi ac nibh dapibus, vitae.
                </p>
            </div>
        </div>
    </div>
  </header>
</template>

<script setup>
import OverviewCard from '../components/home/OverviewCard.vue'
</script>
