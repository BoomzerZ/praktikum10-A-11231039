<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuth } from '../stores/useAuth'

const username = ref('')
const password = ref('')
const confirmPassword = ref('')
const error = ref('')

const router = useRouter()
const { signup } = useAuth()

const handleSubmit = () => {
  error.value = ''

  if (!username.value || !password.value || !confirmPassword.value) {
    error.value = 'Semua field wajib diisi.'
    return
  }

  if (password.value !== confirmPassword.value) {
    error.value = 'Password dan konfirmasi password tidak sama.'
    return
  }

  try {
    signup(username.value, password.value)
    router.push('/') // setelah daftar, arahkan ke halaman utama
  } catch (e) {
    error.value = e.message || 'Terjadi kesalahan saat mendaftar.'
  }
}
</script>

<template>
  <main class="min-h-screen flex items-center justify-center bg-slate-50">
    <div class="w-full max-w-md bg-white rounded-3xl shadow-lg px-8 py-10">
      <!-- Header brand -->
      <div class="text-center mb-6">
        <h1 class="text-2xl font-bold">EdVenture</h1>
        <p class="mt-1 text-gray-500 text-sm">
          Buat akun baru untuk mulai berpetualang
        </p>
      </div>

      <!-- Form -->
      <form @submit.prevent="handleSubmit" class="space-y-5">
        <div>
          <label class="block text-sm font-medium mb-1">Username</label>
          <input
            v-model="username"
            type="text"
            placeholder="Masukkan nama anda di sini"
            class="w-full rounded-full bg-gray-100 px-4 py-3 text-sm outline-none
                   focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Password</label>
          <input
            v-model="password"
            type="password"
            placeholder="Masukkan password"
            class="w-full rounded-full bg-gray-100 px-4 py-3 text-sm outline-none
                   focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Konfirmasi Password</label>
          <input
            v-model="confirmPassword"
            type="password"
            placeholder="Ulangi password"
            class="w-full rounded-full bg-gray-100 px-4 py-3 text-sm outline-none
                   focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <p v-if="error" class="text-sm text-red-500">
          {{ error }}
        </p>

        <button
          type="submit"
          class="w-full rounded-full bg-indigo-600 text-white font-semibold py-3
                 mt-2 hover:bg-indigo-500 transition"
        >
          Sign Up
        </button>
      </form>

      <!-- Link ke login -->
      <p class="mt-5 text-center text-xs text-gray-500">
        Sudah punya akun?
        <router-link to="/login" class="font-semibold text-indigo-600 hover:underline">
          Login di sini
        </router-link>
      </p>
    </div>
  </main>
</template>
