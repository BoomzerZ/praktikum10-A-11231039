<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuth } from '../stores/useAuth'

const username = ref('')
const password = ref('')
const error = ref('')

const router = useRouter()
const { login } = useAuth()

const handleSubmit = () => {
  error.value = ''
  try {
    login(username.value, password.value)
    // setelah login sukses, arahkan ke halaman utama
    router.push('/')
  } catch (e) {
    error.value = e.message
  }
}
</script>

<template>
  <main class="min-h-screen flex items-center justify-center bg-slate-50">
    <div class="w-full max-w-md bg-white rounded-3xl shadow-lg px-8 py-10">
      <h1 class="text-2xl font-bold text-center mb-1">EdVenture</h1>
      <p class="text-center text-gray-500 mb-8">Welcome Back!</p>

      <form @submit.prevent="handleSubmit" class="space-y-5">
        <div>
          <label class="block text-sm font-medium mb-1">Username</label>
          <input
            v-model="username"
            type="text"
            placeholder="Masukkan nama anda di sini"
            class="w-full rounded-full bg-gray-100 px-4 py-3 text-sm outline-none
                   focus:ring-2 focus:ring-indigo-500"
          >
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Password</label>
          <input
            v-model="password"
            type="password"
            placeholder="Masukkan password"
            class="w-full rounded-full bg-gray-100 px-4 py-3 text-sm outline-none
                   focus:ring-2 focus:ring-indigo-500"
          >
        </div>

        <p v-if="error" class="text-sm text-red-500">{{ error }}</p>

        <button
          type="submit"
          class="w-full rounded-full bg-indigo-600 text-white font-semibold py-3
                 mt-2 hover:bg-indigo-500 transition"
        >
          Login
        </button>
      </form>
    </div>
  </main>
</template>
