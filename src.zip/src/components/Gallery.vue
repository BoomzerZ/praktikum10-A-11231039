<script setup>
import { ref, computed } from 'vue'
import { useMonsters } from '../stores/useMonster'

// store progress monster
const { monsters } = useMonsters()

// konfigurasi grid & pagination
const PER_PAGE = 15          // 5 × 3
const TOTAL_PAGES = 8

// jumlah slot tetap, monster sisanya placeholder "???"
const TOTAL_SLOTS = PER_PAGE * TOTAL_PAGES

// bentuk slot: monster + null (kosong)
const slots = computed(() => {
  const base = [...monsters.value]
  const remaining = TOTAL_SLOTS - base.length
  return remaining > 0
    ? [...base, ...Array.from({ length: remaining }, () => null)]
    : base
})

const currentPage = ref(1)

// statistik unlock
const unlockedCount = computed(
  () => monsters.value.filter(m => m.unlocked).length
)
const unlockedPercent = computed(() =>
  ((unlockedCount.value / monsters.value.length) * 100).toFixed(2)
)

// data untuk halaman aktif
const pageMonsters = computed(() => {
  const start = (currentPage.value - 1) * PER_PAGE
  const end = start + PER_PAGE
  return slots.value.slice(start, end)
})

// ------ pagination window + ellipsis ------
const visiblePages = computed(() => {
  const total = TOTAL_PAGES
  const current = currentPage.value
  const pages = []

  if (total <= 5) {
    for (let i = 1; i <= total; i++) pages.push(i)
    return pages
  }

  if (current <= 3) {
    pages.push(1, 2, 3, 4, '…', total)
  } else if (current >= total - 2) {
    pages.push(1, '…', total - 3, total - 2, total - 1, total)
  } else {
    pages.push(1, '…', current - 1, current, current + 1, '…', total)
  }

  return pages
})

function goToPage(page) {
  if (typeof page !== 'number') return
  if (page < 1 || page > TOTAL_PAGES) return
  currentPage.value = page
}

function prevPage() {
  if (currentPage.value > 1) currentPage.value--
}

function nextPage() {
  if (currentPage.value < TOTAL_PAGES) currentPage.value++
}

// ------ modal detail monster ------
const showModal = ref(false)
const selectedMonster = ref(null)

function openMonsterCard(slot) {
  // slot bisa null (placeholder) atau monster
  if (!slot) return
  if (!slot.unlocked) return // kalau belum kebuka, abaikan

  selectedMonster.value = slot
  showModal.value = true
}

function closeModal() {
  showModal.value = false
}
</script>

<template>
  <section class="bg-slate-50 py-20 min-h-screen">
    <div class="mx-auto max-w-6xl px-4">
      <!-- HEADER -->
      <div class="flex items-baseline justify-between mb-10">
        <h1 class="text-3xl sm:text-4xl font-bold text-slate-900">
          Unlockable
          <span class="text-indigo-500 text-2xl">
            - {{ unlockedPercent }}%
          </span>
        </h1>
        <p class="text-sm text-slate-500">
          {{ unlockedCount }} / {{ monsters.length }} Monster unlocked
        </p>
      </div>

      <!-- GRID 5 × 3 -->
      <div
        class="grid gap-8
               sm:grid-cols-2
               md:grid-cols-3
               xl:grid-cols-5"
      >
        <div
          v-for="(slot, index) in pageMonsters"
          :key="index"
          @click="openMonsterCard(slot)"
          :class="[
            'bg-white rounded-3xl border border-slate-100 px-6 py-8 flex flex-col items-center text-center transition',
            slot && slot.unlocked
              ? 'cursor-pointer hover:shadow-lg hover:-translate-y-1'
              : 'opacity-70 cursor-default'
          ]"
        >
          <!-- AVATAR -->
          <div
            class="mb-6 flex h-28 w-28 items-center justify-center rounded-full
                   bg-slate-100 text-slate-400 text-sm font-medium overflow-hidden"
          >
            <!-- unlocked: tampil sprite -->
            <template v-if="slot && slot.unlocked">
              <img
                :src="slot.sprite"
                :alt="slot.name"
                class="h-full w-full object-contain"
              />
            </template>

            <!-- slot monster tapi masih locked -->
            <template v-else-if="slot">
              <span>locked</span>
            </template>

            <!-- slot kosong (belum ada monster di sini sama sekali) -->
            <template v-else>
              <span>???</span>
            </template>
          </div>

          <!-- NAMA -->
          <h3 class="text-lg font-semibold text-slate-900 mb-4">
            <!-- kalau slot adalah monster tapi belum unlocked, tutup namanya -->
            <span v-if="slot && slot.unlocked">{{ slot.name }}</span>
            <span v-else-if="slot">???</span>
            <span v-else>&nbsp;</span>
          </h3>

          <!-- STAT: hanya untuk monster (slot) -->
          <ul v-if="slot" class="space-y-1 text-sm">
            <li class="flex items-center gap-2 justify-center">
              <span class="text-pink-500">❤</span>
              <span class="text-slate-500">
                Health:
                <span class="font-semibold text-slate-800">
                  {{ slot.unlocked ? slot.health : '???' }}
                </span>
              </span>
            </li>
            <li class="flex items-center gap-2 justify-center">
              <span class="text-indigo-500">⚔</span>
              <span class="text-slate-500">
                Attack:
                <span class="font-semibold text-slate-800">
                  {{ slot.unlocked ? slot.attack : '???' }}
                </span>
              </span>
            </li>
            <li class="flex items-center gap-2 justify-center">
              <span class="text-sky-500">🛡</span>
              <span class="text-slate-500">
                Defense:
                <span class="font-semibold text-slate-800">
                  {{ slot.unlocked ? slot.defense : '???' }}
                </span>
              </span>
            </li>
          </ul>
        </div>
      </div>

      <!-- PAGINATION -->
      <div class="mt-12 flex items-center justify-center gap-3">
        <!-- Prev -->
        <button
          @click="prevPage"
          :disabled="currentPage === 1"
          class="flex h-10 w-10 items-center justify-center rounded-full border
                 text-sm font-medium
                 transition
                 disabled:opacity-40 disabled:cursor-not-allowed
                 hover:bg-slate-100"
        >
          ‹
        </button>

        <!-- Numbers + ellipsis -->
        <template v-for="(page, idx) in visiblePages" :key="idx">
          <button
            v-if="page !== '…'"
            @click="goToPage(page)"
            :class="[
              'h-10 w-10 rounded-full flex items-center justify-center text-sm font-medium transition',
              currentPage === page
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-100'
            ]"
          >
            {{ page }}
          </button>
          <span
            v-else
            class="px-1 text-slate-400 select-none"
          >
            …
          </span>
        </template>

        <!-- Next -->
        <button
          @click="nextPage"
          :disabled="currentPage === TOTAL_PAGES"
          class="flex h-10 w-10 items-center justify-center rounded-full border
                 text-sm font-medium
                 transition
                 disabled:opacity-40 disabled:cursor-not-allowed
                 hover:bg-slate-100"
        >
          ›
        </button>
      </div>
    </div>

    <!-- MODAL DETAIL MONSTER -->
    <div
      v-if="showModal && selectedMonster"
      class="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
      @click.self="closeModal"
    >
      <div
        class="bg-white rounded-3xl max-w-md w-full mx-4 p-6 shadow-2xl"
      >
        <div class="flex items-center gap-4 mb-4">
          <div
            class="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden"
          >
            <img
              :src="selectedMonster.sprite"
              :alt="selectedMonster.name"
              class="h-full w-full object-contain"
            />
          </div>
          <div>
            <h2 class="text-xl font-bold text-slate-900">
              {{ selectedMonster.name }}
            </h2>
            <p class="text-sm text-slate-500">
              Dibunuh:
              <span class="font-semibold text-slate-800">
                {{ selectedMonster.killCount }}x
              </span>
            </p>
          </div>
        </div>

        <p class="text-sm text-slate-700 leading-relaxed mb-4">
          {{ selectedMonster.lore }}
        </p>

        <div class="flex justify-end">
          <button
            @click="closeModal"
            class="px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  </section>
</template>
