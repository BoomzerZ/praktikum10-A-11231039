<script setup>
const props = defineProps({
  displayName: { type: String, default: '' },
  bio: { type: String, default: '' },
})

const emits = defineEmits(['update:displayName', 'update:bio', 'save'])

function onSave() {
  emits('save')
}
</script>

<template>
  <section
    class="rounded-2xl bg-white shadow-sm border border-gray-100 p-6 space-y-4"
  >
    <h2 class="text-lg font-semibold text-gray-900">
      Pengaturan Profil
    </h2>

    <div class="grid gap-4 md:grid-cols-2">
      <div class="space-y-1">
        <label class="text-sm font-medium text-gray-700">
          Display Name
        </label>
        <input
          :value="displayName"
          @input="$emit('update:displayName', $event.target.value)"
          type="text"
          class="w-full rounded-full border border-gray-300 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Nama yang ingin ditampilkan"
        />
      </div>

      <div class="space-y-1 md:col-span-2">
        <label class="text-sm font-medium text-gray-700">
          Bio Singkat
        </label>
        <textarea
          :value="bio"
          @input="$emit('update:bio', $event.target.value)"
          rows="3"
          class="w-full rounded-2xl border border-gray-300 px-4 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Ceritakan sedikit tentang dirimu..."
        />
      </div>
    </div>

    <div class="flex justify-end">
      <button
        @click="onSave"
        class="px-6 py-2 rounded-full bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-500"
      >
        Simpan Perubahan
      </button>
    </div>
  </section>
</template>
