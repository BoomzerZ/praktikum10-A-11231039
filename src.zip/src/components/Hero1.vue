<template>
  <header class="pt-16">
    <div class="relative overflow-hidden">
      <div class="bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-400 text-white">
        <div class="mx-auto max-w-5xl px-6 py-20 text-center">
          <h1 class="text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight">EdVenture Arena</h1>
          <p class="mt-4 text-lg md:text-xl text-white/90">Lawan musuh dengan kekuatan pengetahuanmu!</p>

          <div class="mt-10 flex items-center justify-center gap-6">
            <!-- Mulai Bermain -->
            <router-link
              to="/game"
              class="bg-white text-gray-900 font-semibold px-8 py-3 rounded-lg shadow-md 
                    hover:shadow-xl hover:-translate-y-1 transition-all duration-200">
              Mulai Bermain
            </router-link>

            <!-- Pelajari Lanjut -->
            <router-link
              to="/about"
              class="bg-white/20 border border-white/30 text-white font-semibold px-8 py-3 rounded-lg shadow-sm
                    hover:bg-white/30 hover:border-white/60 hover:-translate-y-1 transition-all duration-200">
              Pelajari Lanjut
            </router-link>
          </div>
        </div>
      </div>

      <!-- Floating bubbles -->
      <div aria-hidden="true" class="pointer-events-none absolute left-8 top-12 opacity-30">
        <div class="w-24 h-24 rounded-full bg-white/20"></div>
      </div>
      <div aria-hidden="true" class="pointer-events-none absolute right-12 top-24 opacity-25">
        <div class="w-36 h-36 rounded-full bg-white/15"></div>
      </div>
      <div aria-hidden="true" class="pointer-events-none absolute right-24 bottom-8 opacity-25">
        <div class="w-48 h-48 rounded-full bg-white/10"></div>
      </div>
    </div>
  </header>
</template>
