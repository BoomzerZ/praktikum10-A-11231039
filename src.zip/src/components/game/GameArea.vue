<template>
  <PlayerPanel :hearts="playerHearts" />

  <EnemyPanel :hearts="enemyHearts" :enemyName="enemyName" />

  <QuestionBox :question="currentQuestion" />

  <div class="grid gap-3 mt-6">
    <AnswerOption
      v-for="(opt, i) in currentQuestion.options"
      :key="i"
      :text="opt"
      @click="handleAnswer(i)"
    />
  </div>

  <GameResultModal
    v-if="showModal"
    :status="resultStatus"
    @close="resetGame"
  />
</template>
