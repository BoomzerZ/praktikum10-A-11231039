<template>
  <div class="game-area space-y-6 px-4">
    <div class="flex gap-4 items-start">
      <PlayerPanel :hearts="playerHearts" :maxHearts="maxHearts" />
      <div class="flex-1">
        <QuestionBox
          :question="currentQuestion"
          :disabled="isAnswerLocked"
          @answer="selectAnswer"
        />
      </div>
      <EnemyPanel
        :hearts="enemyHearts"
        :enemyName="enemy.name"
        :maxHearts="enemyMaxHearts"
        :isBoss="enemy.isBoss"
      />
    </div>

    <div class="controls flex gap-2 mt-4">
      <button @click="startGame" class="px-4 py-2 border rounded">Restart</button>
      <div class="ml-auto text-sm text-gray-500">
        Question {{ currentIndex + 1 }} / {{ questions.length }}
      </div>
    </div>

    <GameResultModal v-if="showModal" :status="resultStatus" @close="resetGame" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import PlayerPanel from '../game/PlayerPanel.vue'
import EnemyPanel from '../game/EnemyPanel.vue'
import QuestionBox from '../game/QuestionBox.vue'
import GameResultModal from '../game/GameResult.vue'
import { unlockMonster, incrementKillCount } from '../utils/galleryHelper.js'

/* ---------- data: soal ---------- */
const questions = [
  { text: '2 + 2 = ?', options: ['3','4','5','6'], correctIndex: 1 },
  { text: 'Ibu kota Indonesia?', options: ['Jakarta','Bandung','Surabaya','Medan'], correctIndex: 0 },
  { text: 'Benua terbesar?', options: ['Afrika','Asia','Eropa','Antartika'], correctIndex: 1 },
]

/* ---------- monsters: definisikan dulu ---------- */
const monsters = [
  { id: 1, name: 'Slime', hearts: 3, isBoss: false },
  { id: 2, name: 'Goblin', hearts: 3, isBoss: false },
  { id: 3, name: 'Orc', hearts: 4, isBoss: false },
  { id: 4, name: 'Troll', hearts: 4, isBoss: false },
  { id: 5, name: 'Wyvern', hearts: 5, isBoss: false },
  { id: 6, name: 'Giant', hearts: 5, isBoss: false },
  { id: 7, name: 'Hydra', hearts: 5, isBoss: false },
  { id: 8, name: 'Phantom', hearts: 5, isBoss: false },
  { id: 9, name: 'Warlord', hearts: 6, isBoss: false },
  { id: 10, name: 'Dragon', hearts: 6, isBoss: true }
]

/* ---------- state ---------- */
const maxHearts = 3             // player max hearts
const playerHearts = ref(maxHearts)

const currentIndex = ref(0)     // soal index
const showModal = ref(false)
const resultStatus = ref('')    // 'win'|'lose'|'draw'
const isAnswerLocked = ref(false)

const level = ref(1)
const currentMonsterIndex = ref(0) // index of monsters[]
const enemy = computed(() => monsters[currentMonsterIndex.value] || monsters[0])
const enemyMaxHearts = computed(() => enemy.value?.hearts ?? 3)
const enemyHearts = ref(enemyMaxHearts.value) // init, but we set properly in loadNextMonster()

/* ---------- computed ---------- */
const currentQuestion = computed(() => questions[currentIndex.value] || questions[0])

/* ---------- helper: load & reset ---------- */
function loadNextMonster() {
  // set enemy hp based on current monster
  enemyHearts.value = enemy.value?.hearts ?? maxHearts
  currentIndex.value = 0
  isAnswerLocked.value = false
}

function startGame() {
  playerHearts.value = maxHearts
  currentMonsterIndex.value = 0
  level.value = 1
  showModal.value = false
  resultStatus.value = ''
  loadNextMonster()
}

function resetGame() {
  startGame()
}

/* ---------- unlock gallery placeholder ---------- */
function unlockMonster(id) {
  try {
    const unlocked = JSON.parse(localStorage.getItem('unlocked') || '[]')
    if (!unlocked.includes(id)) {
      unlocked.push(id)
      localStorage.setItem('unlocked', JSON.stringify(unlocked))
    }
  } catch (e) { /* ignore parse errors */ }
}

/* ---------- when enemy defeated ---------- */
function handleEnemyDefeated() {
  unlockMonster(enemy.value.id)
  incrementKillCount(enemy.value.id)

  if (enemy.value.isBoss) {
    resultStatus.value = 'win'
    showModal.value = true
    return
  }

  // move to next monster
  level.value++
  currentMonsterIndex.value = Math.min(currentMonsterIndex.value + 1, monsters.length - 1)
  loadNextMonster()
}

/* ---------- selection logic ---------- */
function selectAnswer(selectedIndex) {
  if (showModal.value || isAnswerLocked.value) return
  isAnswerLocked.value = true

  const correct = selectedIndex === (currentQuestion.value?.correctIndex ?? -1)

  if (correct) {
    // enemy hurt
    enemyHearts.value = Math.max(0, enemyHearts.value - 1)

    if (enemyHearts.value <= 0) {
      // defeated
      handleEnemyDefeated()
      // no immediate question increment here — next monster will reset questions
      setTimeout(() => { isAnswerLocked.value = false }, 400)
      return
    }

    // go to next question
    currentIndex.value++
    if (currentIndex.value >= questions.length) currentIndex.value = 0

    // unlock after short delay so UI has time to show feedback
    setTimeout(() => { isAnswerLocked.value = false }, 300)

  } else {
    // player hurt
    playerHearts.value = Math.max(0, playerHearts.value - 1)
    if (playerHearts.value <= 0) {
      resultStatus.value = 'lose'
      showModal.value = true
      return
    }
    // next question
    currentIndex.value++
    if (currentIndex.value >= questions.length) currentIndex.value = 0
    setTimeout(() => { isAnswerLocked.value = false }, 300)
  }
}

/* ---------- startup ---------- */
onMounted(() => {
  startGame()
})
</script>

<style scoped>
.game-area { padding: 12px; }
</style>
