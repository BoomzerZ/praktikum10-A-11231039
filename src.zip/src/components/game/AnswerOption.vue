<template>
  <button
    class="p-4 bg-white rounded-xl shadow hover:bg-indigo-50 transition disabled:opacity-60"
    :disabled="disabled"
    @click="$emit('select')"
  >
    {{ text }}
  </button>
</template>

<script setup>
defineProps({
  text: String,
  disabled: { type: Boolean, default: false }
})
</script>
