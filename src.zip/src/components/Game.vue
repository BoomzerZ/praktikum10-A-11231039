<script setup>
import { ref, computed } from 'vue'
import { useMonsters } from '../stores/useMonster'

// store progress monster
const { unlockAndCount } = useMonsters()

// state animasi scene
const scene = ref('idle') // 'idle' | 'attack' | 'hit'

// level & progress
const level = ref(1)
const levelProgress = ref(0) // 0–100

// nyawa
const playerHearts = ref(3)
const enemyHearts = ref(3)

// pertanyaan
const currentQuestionIndex = ref(0)

const questions = [
  {
    text: 'Ada berapa Planet dalam tata surya kita?',
    options: ['6', '8', '7', '9'],
    correctIndex: 1,
  },
  {
    text: 'Ibu kota Indonesia adalah?',
    options: ['Bandung', 'Surabaya', 'Jakarta', 'Medan'],
    correctIndex: 2,
  },
  {
    text: 'Lambang unsur H dalam tabel periodik adalah?',
    options: ['Helium', 'Hafnium', 'Hidrogen', 'Holmium'],
    correctIndex: 2,
  },
  // tambah pertanyaan lain di sini kalau mau
]

const currentQuestion = computed(() => questions[currentQuestionIndex.value])

// ganti scene / gambar battle (sesuaikan path asset yg kamu punya)
const sceneSrc = computed(() => {
  if (scene.value === 'attack') return '/src/assets/scene_attack.png'
  if (scene.value === 'hit') return '/src/assets/scene_hit.png'
  return '/src/assets/scene_idle.png'
})

const isGameOver = ref(false)
const isEnemyDefeated = ref(false)
const message = ref('')

// ------------- util -------------
function resetRound() {
  playerHearts.value = 3
  enemyHearts.value = 3
  isGameOver.value = false
  isEnemyDefeated.value = false
  message.value = ''
  scene.value = 'idle'
}

// ganti ke pertanyaan berikut SETIAP kali dapat jawaban benar
function gotoNextQuestion() {
  currentQuestionIndex.value =
    (currentQuestionIndex.value + 1) % questions.length
}

// hearts helper
function heartsArray(count) {
  return Array.from({ length: 3 }, (_, i) => i < count)
}

// ------------- main logic -------------
function handleAnswer(index) {
  if (isGameOver.value || isEnemyDefeated.value) return

  const correct = index === currentQuestion.value.correctIndex

  if (correct) {
    scene.value = 'attack'
    enemyHearts.value--

    // pertanyaan langsung ganti tiap jawaban BENAR
    gotoNextQuestion()

    // progress bar naik sedikit
    levelProgress.value = Math.min(levelProgress.value + 20, 100)

    if (enemyHearts.value <= 0) {
      isEnemyDefeated.value = true
      message.value = 'Kamu berhasil mengalahkan musuh!'

      // contoh: musuh sekarang adalah Goblin
      unlockAndCount('goblin')

      level.value++

      setTimeout(() => {
        resetRound()
      }, 1200)
    }
  } else {
    scene.value = 'hit'
    playerHearts.value--

    if (playerHearts.value <= 0) {
      isGameOver.value = true
      message.value = 'Game Over! Nyawamu habis.'

      setTimeout(() => {
        level.value = 1
        levelProgress.value = 0
        currentQuestionIndex.value = 0
        resetRound()
      }, 1500)
    }
  }

  // kembali ke idle kalau belum game over
  setTimeout(() => {
    if (!isGameOver.value && !isEnemyDefeated.value) {
      scene.value = 'idle'
    }
  }, 600)
}
</script>

<template>
  <section class="bg-slate-50 py-8">
    <div class="mx-auto max-w-4xl px-6 space-y-4">

      <!-- LAYAR GAME -->
      <div
        class="bg-black rounded-3xl overflow-hidden shadow-xl border border-gray-800"
      >
        <div class="bg-gray-900">
          <img
            :src="sceneSrc"
            alt="Battle Scene"
            class="w-full max-h-[300px] object-cover"
          />
        </div>
      </div>

      <!-- HP BAR -->
      <div
        class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-b from-gray-100 to-slate-50 rounded-3xl px-4 py-3 shadow-sm"
      >
        <!-- Player -->
        <div class="flex items-center gap-3">
          <div
            class="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-md border border-gray-200"
          >
            <span class="text-xs font-semibold text-gray-800">YOU</span>
          </div>
          <div>
            <p class="text-xs font-semibold text-gray-700">Player</p>
            <div class="flex gap-1">
              <span
                v-for="(full, i) in heartsArray(playerHearts)"
                :key="'p-' + i"
                class="text-lg"
                :class="full ? 'text-red-500' : 'text-gray-300'"
              >
                ♥
              </span>
            </div>
          </div>
        </div>

        <!-- Enemy -->
        <div class="flex items-center gap-3 sm:justify-end">
          <div class="text-right">
            <p class="text-xs font-semibold text-gray-700">Goblin</p>
            <div class="flex gap-1 justify-end">
              <span
                v-for="(full, i) in heartsArray(enemyHearts)"
                :key="'e-' + i"
                class="text-lg"
                :class="full ? 'text-red-500' : 'text-gray-300'"
              >
                ♥
              </span>
            </div>
          </div>
          <div
            class="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-md border border-gray-200"
          >
            <span class="text-xs font-semibold text-gray-800">NPC</span>
          </div>
        </div>
      </div>

      <!-- PERTANYAAN -->
      <div class="text-center mt-4">
        <p class="text-sm sm:text-base font-semibold text-gray-900">
          {{ currentQuestion.text }}
        </p>
      </div>

      <!-- OPSI JAWABAN -->
      <div class="grid gap-4 mt-4 md:grid-cols-2">
        <button
          v-for="(option, index) in currentQuestion.options"
          :key="index"
          @click="handleAnswer(index)"
          class="flex items-center justify-start gap-3 rounded-2xl border border-gray-300 bg-white px-5 py-4 text-left text-sm font-semibold text-gray-800 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 disabled:opacity-60 disabled:cursor-not-allowed"
          :disabled="showModal"
        >
          <span class="font-bold">
            {{ String.fromCharCode(65 + index) }}.
          </span>
          <span>{{ option }}</span>
        </button>
      </div>
    </div>

    <!-- POPUP GAME OVER / WIN -->
    <div
      v-if="showModal"
      class="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
    >
      <div class="bg-white rounded-2xl shadow-xl max-w-sm w-full mx-4 p-6">
        <h2 class="text-xl font-bold mb-2 text-gray-900 text-center">
          {{ modalTitle }}
        </h2>
        <p class="text-sm text-gray-700 text-center mb-6">
          {{ modalText }}
        </p>
        <div class="flex justify-center">
          <button
            @click="resetGame"
            class="px-6 py-2 rounded-full bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-500"
          >
            Main Lagi
          </button>
        </div>
      </div>
    </div>
  </section>
</template>
