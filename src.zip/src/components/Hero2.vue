<template>
  <header class="pt-16">
    <div class="bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-400 text-white">
      <div class="cocontainer mx-auto px-6 py-20 text-center min-h-[260px] flex flex-col justify-center">
        <h1
          class="text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight"
        >
          Tentang EdVenture Arena
        </h1>
        <p
          class="mt-4 text-sm md:text-base lg:text-lg text-white/90"
        >
          Platform edukasi interaktif yang mengubah belajar menjadi petualangan seru
        </p>
      </div>
    </div>
  </header>
</template>
