<script setup>
const props = defineProps({
  initial: { type: String, required: true },
  username: { type: String, required: true },
  bio: { type: String, required: true },
})
</script>

<template>
  <section class="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
    <div class="flex items-center gap-4">
      <div
        class="flex items-center justify-center h-16 w-16 rounded-full bg-indigo-600 text-white text-2xl font-bold"
      >
        {{ initial }}
      </div>
      <div>
        <h1 class="text-2xl font-bold text-gray-900">
          {{ username }}
        </h1>
        <p class="text-sm text-gray-600">
          {{ bio }}
        </p>
      </div>
    </div>

    <div class="text-sm text-gray-500">
      <p>Member EdVenture Arena</p>
    </div>
  </section>
</template>