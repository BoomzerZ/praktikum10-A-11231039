<script setup>
const props = defineProps({
  stats: {
    type: Object,
    required: true,
  },
})
</script>

<template>
  <section class="grid gap-4 md:grid-cols-4">
    <div class="rounded-2xl bg-white shadow-sm border border-gray-100 p-4">
      <p class="text-xs font-medium text-gray-500">Level</p>
      <p class="mt-2 text-2xl font-bold text-indigo-600">
        {{ stats.level }}
      </p>
    </div>

    <div class="rounded-2xl bg-white shadow-sm border border-gray-100 p-4">
      <p class="text-xs font-medium text-gray-500">Musuh dikalahkan</p>
      <p class="mt-2 text-2xl font-bold text-indigo-600">
        {{ stats.monstersDefeated }}
      </p>
    </div>

    <div class="rounded-2xl bg-white shadow-sm border border-gray-100 p-4">
      <p class="text-xs font-medium text-gray-500">Jawaban benar</p>
      <p class="mt-2 text-2xl font-bold text-indigo-600">
        {{ stats.correctAnswers }}
      </p>
    </div>

    <div class="rounded-2xl bg-white shadow-sm border border-gray-100 p-4">
      <p class="text-xs font-medium text-gray-500">Waktu bermain</p>
      <p class="mt-2 text-2xl font-bold text-indigo-600">
        {{ stats.playTime }}
      </p>
    </div>
  </section>
</template>